If you are adding a new project to the list please follow these rules:

- Add only open source projects
- Make sure the project cite this repo as a data source (with a link) 
- Follow the same order as the rest of the list `- [project-name](your-project-url) ([repo](repo-url)): description`
- Try not to add extra blank lines, it breaks the formatting
