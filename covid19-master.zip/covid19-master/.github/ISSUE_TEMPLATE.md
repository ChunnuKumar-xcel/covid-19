If it's a data issue please **check the source repo first**. We use the data from these files:

- [Confirmed csv](https://git.io/JvyQR)
- [Deaths csv](https://git.io/JvyQ8)
- [Recovered csv](https://git.io/JvHaX)

If the error is there too, open an issue in that repo.
